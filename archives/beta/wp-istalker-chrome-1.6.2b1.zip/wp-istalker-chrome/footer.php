<?php wpi_section_start('content-end');?>
<?php wpi_section_end();?>
<?php wpi_section_start('footer');?>
<?php do_action('wp_footer'); ?>
<?php wpi_section_end();?>
</dl>
<?php do_action(wpiFilter::ACTION_FOOTER_SCRIPT);?>
<!-- 
	Spreading Microformats 
	Plain old semantic markup (POSH) and designed by Avice (ChaosKaizer) De'v&eacute;reux  
	<http://blog.kaizeku.com>

 	Wp-iStalker Public themes can be found at http://wp-istalker.googlecode.com	  
-->
</body>
</html>